# gerber_renderer
Python library for rendering gerber PCB files as svgs.
